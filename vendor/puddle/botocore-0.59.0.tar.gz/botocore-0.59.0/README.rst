botocore
========

|Build Status|

A low-level interface to a growing number of Amazon Web Services. The
botocore package is the foundation for
`AWS-CLI <https://github.com/aws/aws-cli>`__.

`Documentation <https://botocore.readthedocs.org/en/latest/>`__

.. |Build Status| image:: https://travis-ci.org/boto/botocore.png?branch=develop
   :target: https://travis-ci.org/boto/botocore
