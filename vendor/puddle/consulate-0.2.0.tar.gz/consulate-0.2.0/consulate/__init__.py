"""
Consulate: A client library for Consul

"""
__version__ = '0.2.0'

from consulate.api import Consulate
from consulate.api import TornadoConsulate
