**To delete a virtual private gateway**

This example deletes the specified virtual private gateway.

Command::

  aws ec2 delete-vpn-gateway --vpn-gateway-id vgw-9a4cacf3

Output::

  {
      "return": "true"
  }