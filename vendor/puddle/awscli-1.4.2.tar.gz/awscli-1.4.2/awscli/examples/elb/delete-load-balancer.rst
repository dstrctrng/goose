**To delete load balancer**

This example deletes a specified load balancer.

Command::

      aws elb delete-load-balancer --load-balancer-name MyLoadBalancer


Output::

         {}

