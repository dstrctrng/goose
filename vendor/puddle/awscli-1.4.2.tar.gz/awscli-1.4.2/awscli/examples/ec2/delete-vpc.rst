**To delete a VPC**

This example deletes the specified VPC.

Command::

  aws ec2 delete-vpc --vpc-id vpc-a01106c2

Output::

  {
      "return": "true"
  }