**To delete a VPC peering connection**

This example deletes the specified VPC peering connection.

Command::

  aws ec2 delete-vpc-peering-connection --vpc-peering-connection-id pcx-1a2b3c4d

Output::

  {
      "return": "true"
  }