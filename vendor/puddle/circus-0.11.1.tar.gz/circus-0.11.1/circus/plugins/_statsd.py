# kept for backwards compatibility
from circus.plugins.statsd import StatsdEmitter   # NOQA
