======
Circus
======

Circus is a program that runs and watches processes and sockets.
Circus can be used as a library or through the command line.

.. image:: https://secure.travis-ci.org/mozilla-services/circus.png?branch=master
   :alt: Build Status
   :target: https://secure.travis-ci.org/mozilla-services/circus
.. image:: https://coveralls.io/repos/mozilla-services/circus/badge.png?branch=master
   :alt: Coverage Status on master
   :target: https://coveralls.io/r/mozilla-services/circus?branch=master
.. image:: https://pypip.in/v/circus/badge.png
   :target: https://python.org/pypi/circus/
.. image:: https://pypip.in/d/circus/badge.png
   :target: https://python.org/pypi/circus/

Links:

- Full Documentation : http://circus.readthedocs.org
- How to Contribute : http://circus.readthedocs.org/en/latest/contributing/
- Mailing List : http://tech.groups.yahoo.com/group/circus-dev/
- Repository & Issue Tracker : https://github.com/mozilla-services/circus
- IRC : Freenode, channel #mozilla-circus
