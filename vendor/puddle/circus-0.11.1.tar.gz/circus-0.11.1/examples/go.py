from time import sleep

try:
    while True:
        sleep(1)
except Exception:
    pass

