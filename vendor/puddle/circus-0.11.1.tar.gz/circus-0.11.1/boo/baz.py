
def ok():
    pass
